<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel React</title>

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body>
    <div id="hello-react"></div>
</body>
</html><?php /**PATH /Users/rajashilan/agiledev_backend/bookshop/resources/views/welcome.blade.php ENDPATH**/ ?>